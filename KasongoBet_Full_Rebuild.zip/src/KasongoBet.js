export default function KasongoBet() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-red-900 to-black text-white font-sans p-4">
      <header className="text-center py-6">
        <h1 className="text-4xl font-bold text-yellow-400">KASONGOBET</h1>
        <p className="text-sm italic text-red-300">Sema Wantam - Your Trusted Betting Partner</p>
      </header>
      <main className="max-w-xl mx-auto bg-red-800 rounded-2xl shadow-lg p-6 space-y-6">
        <section className="text-center">
          <h2 className="text-2xl font-semibold mb-2">Place Your Bet</h2>
          <select className="w-full p-2 rounded bg-red-700 text-white">
            <option value="match1">AFC Leopards vs Gor Mahia</option>
            <option value="match2">Man City vs Arsenal</option>
            <option value="match3">Kariobangi Sharks vs Tusker FC</option>
          </select>
        </section>
        <section className="text-center">
          <label className="block mb-1">Amount (KES)</label>
          <input type="number" placeholder="e.g. 100" className="w-full p-2 rounded bg-red-700 text-white" />
        </section>
        <button className="w-full bg-yellow-500 text-black font-bold py-2 rounded hover:bg-yellow-400">
          Place Bet
        </button>
        <div className="text-sm text-center text-gray-300">
          Odds are updated in real time. Minimum bet: KES 20
        </div>
      </main>
      <footer className="text-center mt-10 text-gray-400 text-xs">
        &copy; {new Date().getFullYear()} KasongoBet | Bet responsibly | Powered by M-Pesa
      </footer>
    </div>
  );
}