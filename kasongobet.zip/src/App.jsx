
import React from 'react';
import './style.css';

const App = () => {
  return (
    <div className="app">
      <h1>Welcome to KasongoBet 🎯</h1>
      <p>Experience AviatedX, Sports Betting, and More!</p>
    </div>
  );
};

export default App;
